# what it does
provide a useful class which has toDict() method.
